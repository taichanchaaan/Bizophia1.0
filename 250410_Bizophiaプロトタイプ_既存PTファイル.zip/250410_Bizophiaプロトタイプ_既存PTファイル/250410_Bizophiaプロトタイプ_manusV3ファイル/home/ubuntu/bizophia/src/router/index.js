import Home from '../views/Home.vue';
import IndustrySelection from '../views/IndustrySelection.vue';
import EntrepreneurLevel from '../views/EntrepreneurLevel.vue';
import MotivationSelection from '../views/MotivationSelection.vue';
import CourseOverview from '../views/CourseOverview.vue';
import SimulationSession from '../views/SimulationSession.vue';
import SessionComplete from '../views/SessionComplete.vue';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/industry-selection',
    name: 'IndustrySelection',
    component: IndustrySelection
  },
  {
    path: '/entrepreneur-level',
    name: 'EntrepreneurLevel',
    component: EntrepreneurLevel
  },
  {
    path: '/motivation-selection',
    name: 'MotivationSelection',
    component: MotivationSelection
  },
  {
    path: '/course-overview',
    name: 'CourseOverview',
    component: CourseOverview
  },
  {
    path: '/simulation-session',
    name: 'SimulationSession',
    component: SimulationSession
  },
  {
    path: '/session-complete',
    name: 'SessionComplete',
    component: SessionComplete
  }
];

export default routes;
