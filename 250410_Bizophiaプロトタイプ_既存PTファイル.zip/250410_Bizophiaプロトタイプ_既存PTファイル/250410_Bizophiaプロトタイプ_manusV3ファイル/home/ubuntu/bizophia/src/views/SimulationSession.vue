<template>
  <div class="simulation-session">
    <div class="header">
      <div class="progress-indicator">
        <div class="progress-bar">
          <div class="progress" :style="{ width: progressPercentage + '%' }"></div>
        </div>
        <div class="question-counter">問題 {{ currentQuestionIndex + 1 }}/{{ totalQuestions }}</div>
      </div>
    </div>
    
    <div class="container">
      <div v-if="currentQuestion">
        <h3 class="question-prompt">{{ currentQuestion.prompt }}</h3>
        
        <div v-if="currentQuestion.scenario" class="scenario">
          {{ currentQuestion.scenario }}
        </div>
        
        <!-- 自由記述系 -->
        <div v-if="currentQuestion.type === 'free_text'" class="question-content">
          <textarea 
            v-model="userAnswer" 
            class="text-input" 
            placeholder="ここに回答を入力してください..."
            rows="5"
          ></textarea>
        </div>
        
        <!-- 4択系 -->
        <div v-if="currentQuestion.type === 'multiple_choice'" class="question-content">
          <div 
            v-for="(option, index) in currentQuestion.options" 
            :key="index"
            class="option"
            :class="{ 'selected': userAnswer === index }"
            @click="selectOption(index)"
          >
            {{ option }}
          </div>
        </div>
        
        <!-- シナリオ選択系 -->
        <div v-if="currentQuestion.type === 'scenario_choice'" class="question-content">
          <div 
            v-for="(option, index) in currentQuestion.options" 
            :key="index"
            class="option"
            :class="{ 'selected': userAnswer === index }"
            @click="selectOption(index)"
          >
            {{ option }}
          </div>
        </div>
        
        <!-- 穴埋め系 -->
        <div v-if="currentQuestion.type === 'fill_in_blank'" class="question-content">
          <div class="fill-in-template">
            <span>私たちのビジネスは主に </span>
            <input 
              v-model="blankAnswers.blank1" 
              class="blank-input" 
              placeholder="収益源"
            />
            <span> から収益を得る予定です。この収益モデルを選んだ理由は </span>
            <input 
              v-model="blankAnswers.blank2" 
              class="blank-input" 
              placeholder="理由"
            />
            <span> です。</span>
          </div>
        </div>
        
        <!-- 二択強制選択系 -->
        <div v-if="currentQuestion.type === 'binary_choice'" class="question-content">
          <div 
            v-for="(option, index) in currentQuestion.options" 
            :key="index"
            class="option binary-option"
            :class="{ 'selected': userAnswer === index }"
            @click="selectOption(index)"
          >
            {{ option }}
          </div>
        </div>
        
        <!-- フィードバック表示 -->
        <div v-if="feedback" class="feedback">
          <div class="feedback-content">
            {{ feedback }}
          </div>
        </div>
        
        <div class="navigation">
          <button class="btn-text" @click="skipQuestion">スキップ</button>
          <button 
            v-if="!feedback" 
            class="btn-primary" 
            :disabled="!isAnswerValid" 
            @click="submitAnswer"
          >回答する</button>
          <button 
            v-else 
            class="btn-primary" 
            @click="nextQuestion"
          >次へ</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'SimulationSession',
  setup() {
    const router = useRouter();
    const store = useStore();
    
    const currentQuestionIndex = computed(() => store.state.currentQuestion);
    const totalQuestions = computed(() => store.state.questions.length);
    const currentQuestion = computed(() => store.getters.currentQuestion);
    
    const userAnswer = ref('');
    const blankAnswers = ref({
      blank1: '',
      blank2: ''
    });
    const feedback = ref('');
    
    const progressPercentage = computed(() => {
      return ((currentQuestionIndex.value + 1) / totalQuestions.value) * 100;
    });
    
    const isAnswerValid = computed(() => {
      if (!currentQuestion.value) return false;
      
      switch (currentQuestion.value.type) {
        case 'free_text':
          return userAnswer.value.trim().length > 0;
        case 'multiple_choice':
        case 'scenario_choice':
        case 'binary_choice':
          return userAnswer.value !== '' && userAnswer.value !== null;
        case 'fill_in_blank':
          return blankAnswers.value.blank1.trim().length > 0 && 
                 blankAnswers.value.blank2.trim().length > 0;
        default:
          return false;
      }
    });
    
    const selectOption = (index) => {
      userAnswer.value = index;
    };
    
    const submitAnswer = async () => {
      let answer;
      
      switch (currentQuestion.value.type) {
        case 'free_text':
          answer = userAnswer.value;
          break;
        case 'multiple_choice':
        case 'scenario_choice':
        case 'binary_choice':
          answer = userAnswer.value;
          break;
        case 'fill_in_blank':
          answer = {
            blank1: blankAnswers.value.blank1,
            blank2: blankAnswers.value.blank2
          };
          break;
      }
      
      const result = await store.dispatch('submitAnswer', answer);
      feedback.value = result;
    };
    
    const nextQuestion = () => {
      if (currentQuestionIndex.value < totalQuestions.value - 1) {
        store.dispatch('nextQuestion');
        resetAnswerInputs();
        feedback.value = '';
      } else {
        completeSession();
      }
    };
    
    const skipQuestion = () => {
      nextQuestion();
    };
    
    const resetAnswerInputs = () => {
      userAnswer.value = '';
      blankAnswers.value = {
        blank1: '',
        blank2: ''
      };
    };
    
    const completeSession = async () => {
      await store.dispatch('completeSession');
      router.push('/session-complete');
    };
    
    onMounted(() => {
      // セッション開始時に最初の問題にリセット
      store.commit('SET_CURRENT_QUESTION', 0);
      resetAnswerInputs();
    });
    
    return {
      currentQuestionIndex,
      totalQuestions,
      currentQuestion,
      userAnswer,
      blankAnswers,
      feedback,
      progressPercentage,
      isAnswerValid,
      selectOption,
      submitAnswer,
      nextQuestion,
      skipQuestion
    };
  }
});
</script>

<style scoped>
.simulation-session {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.header {
  padding: 20px;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.progress-indicator {
  width: 100%;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background-color: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 10px;
}

.progress {
  height: 100%;
  background-color: var(--primary-color);
  transition: width 0.3s ease;
}

.question-counter {
  font-size: 0.9rem;
  color: var(--text-color-secondary);
  text-align: right;
}

.container {
  flex: 1;
  padding: 20px;
  display: flex;
  flex-direction: column;
}

.question-prompt {
  margin-bottom: 20px;
}

.scenario {
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 20px;
  font-style: italic;
}

.question-content {
  margin-bottom: 30px;
}

.text-input {
  width: 100%;
  padding: 15px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 1rem;
  resize: vertical;
}

.text-input:focus {
  outline: none;
  border-color: var(--primary-color);
}

.option {
  padding: 15px;
  background-color: white;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  margin-bottom: 10px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.option:hover {
  border-color: var(--primary-color);
  transform: translateY(-2px);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.option.selected {
  border: 2px solid var(--primary-color);
  background-color: rgba(52, 152, 219, 0.1);
}

.binary-option {
  padding: 20px;
  text-align: center;
}

.fill-in-template {
  line-height: 2;
}

.blank-input {
  padding: 5px 10px;
  border: none;
  border-bottom: 2px solid var(--primary-color);
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 1rem;
  width: 150px;
  margin: 0 5px;
}

.blank-input:focus {
  outline: none;
}

.feedback {
  margin-bottom: 30px;
  animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.feedback-content {
  background-color: rgba(46, 204, 113, 0.1);
  border-left: 4px solid var(--success-color);
  padding: 15px;
  border-radius: 0 8px 8px 0;
}

.navigation {
  display: flex;
  justify-content: space-between;
  margin-top: auto;
}

.btn-text {
  background: none;
  border: none;
  color: var(--text-color-secondary);
  cursor: pointer;
  padding: 10px;
  font-size: 1rem;
}

.btn-text:hover {
  color: var(--text-color);
}

@media (max-width: 767px) {
  .blank-input {
    width: 120px;
  }
}
</style>
