<template>
  <div class="entrepreneur-level">
    <div class="header">
      <div class="progress-indicator">
        <div class="progress-bar">
          <div class="progress" :style="{ width: '40%' }"></div>
        </div>
      </div>
    </div>
    
    <div class="container">
      <h2 class="title">あなたの起業経験や知識レベルを教えてください</h2>
      
      <div class="level-options">
        <div 
          v-for="(level, index) in levels" 
          :key="index"
          class="level-option"
          :class="{ 'selected': selectedLevel === level.value }"
          @click="selectLevel(level.value)"
        >
          <div class="radio-button">
            <div class="radio-inner" v-if="selectedLevel === level.value"></div>
          </div>
          <div class="level-content">
            <div class="level-title">{{ level.title }}</div>
            <div class="level-description">{{ level.description }}</div>
          </div>
        </div>
      </div>
      
      <div class="navigation">
        <button class="btn-secondary" @click="goBack">戻る</button>
        <button 
          class="btn-primary" 
          :disabled="!selectedLevel" 
          @click="goNext"
        >次へ</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'EntrepreneurLevel',
  setup() {
    const router = useRouter();
    const store = useStore();
    const selectedLevel = ref('');
    
    const levels = [
      {
        title: '初心者',
        value: 'beginner',
        description: '起業について考え始めたばかり'
      },
      {
        title: '初級',
        value: 'novice',
        description: '基本的な知識はあるが、実践経験はない'
      },
      {
        title: '中級',
        value: 'intermediate',
        description: 'ビジネスプランを作成したことがある'
      },
      {
        title: '上級',
        value: 'advanced',
        description: '起業経験がある'
      }
    ];
    
    const selectLevel = (level) => {
      selectedLevel.value = level;
    };
    
    const goNext = () => {
      if (selectedLevel.value) {
        store.dispatch('setEntrepreneurLevel', selectedLevel.value);
        router.push('/motivation-selection');
      }
    };
    
    const goBack = () => {
      router.push('/industry-selection');
    };
    
    return {
      levels,
      selectedLevel,
      selectLevel,
      goNext,
      goBack
    };
  }
});
</script>

<style scoped>
.entrepreneur-level {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.header {
  padding: 20px;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.progress-indicator {
  width: 100%;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background-color: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.progress {
  height: 100%;
  background-color: var(--primary-color);
  transition: width 0.3s ease;
}

.container {
  flex: 1;
  padding: 20px;
  display: flex;
  flex-direction: column;
}

.title {
  margin-bottom: 30px;
  text-align: center;
}

.level-options {
  display: flex;
  flex-direction: column;
  gap: 15px;
  margin-bottom: 40px;
}

.level-option {
  display: flex;
  align-items: flex-start;
  padding: 15px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: all 0.2s ease;
}

.level-option:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.level-option.selected {
  border: 2px solid var(--primary-color);
  background-color: rgba(52, 152, 219, 0.1);
}

.radio-button {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  border: 2px solid var(--text-color-secondary);
  margin-right: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.level-option.selected .radio-button {
  border-color: var(--primary-color);
}

.radio-inner {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: var(--primary-color);
}

.level-content {
  flex: 1;
}

.level-title {
  font-weight: 700;
  margin-bottom: 5px;
}

.level-description {
  color: var(--text-color-secondary);
  font-size: 0.9rem;
}

.navigation {
  display: flex;
  justify-content: space-between;
  margin-top: auto;
}

@media (max-width: 767px) {
  .level-option {
    padding: 12px;
  }
  
  .radio-button {
    width: 20px;
    height: 20px;
  }
  
  .radio-inner {
    width: 10px;
    height: 10px;
  }
}
</style>
