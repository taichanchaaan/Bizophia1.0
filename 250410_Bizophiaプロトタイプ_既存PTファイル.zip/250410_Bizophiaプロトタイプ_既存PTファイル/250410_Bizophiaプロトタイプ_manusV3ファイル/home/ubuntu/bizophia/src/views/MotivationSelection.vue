<template>
  <div class="motivation-selection">
    <div class="header">
      <div class="progress-indicator">
        <div class="progress-bar">
          <div class="progress" :style="{ width: '60%' }"></div>
        </div>
      </div>
    </div>
    
    <div class="container">
      <h2 class="title">なぜ起業に興味がありますか？</h2>
      <p class="subtitle">（複数選択可）</p>
      
      <div class="motivation-options">
        <div 
          v-for="(motivation, index) in motivations" 
          :key="index"
          class="motivation-option"
          :class="{ 'selected': selectedMotivations.includes(motivation.value) }"
          @click="toggleMotivation(motivation.value)"
        >
          <div class="checkbox">
            <div class="checkbox-inner" v-if="selectedMotivations.includes(motivation.value)"></div>
          </div>
          <div class="motivation-text">{{ motivation.text }}</div>
        </div>
      </div>
      
      <div class="navigation">
        <button class="btn-secondary" @click="goBack">戻る</button>
        <button 
          class="btn-primary" 
          :disabled="selectedMotivations.length === 0" 
          @click="goNext"
        >次へ</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'MotivationSelection',
  setup() {
    const router = useRouter();
    const store = useStore();
    const selectedMotivations = ref([]);
    
    const motivations = [
      {
        text: '自分のアイデアを実現したい',
        value: 'realize_idea'
      },
      {
        text: '自由な働き方を求める',
        value: 'freedom'
      },
      {
        text: '社会に影響を与えたい',
        value: 'social_impact'
      },
      {
        text: '経済的成功を目指したい',
        value: 'financial_success'
      },
      {
        text: 'その他',
        value: 'other'
      }
    ];
    
    const toggleMotivation = (motivation) => {
      if (selectedMotivations.value.includes(motivation)) {
        selectedMotivations.value = selectedMotivations.value.filter(m => m !== motivation);
      } else {
        selectedMotivations.value.push(motivation);
      }
    };
    
    const goNext = () => {
      if (selectedMotivations.value.length > 0) {
        store.dispatch('setMotivations', selectedMotivations.value);
        router.push('/course-overview');
      }
    };
    
    const goBack = () => {
      router.push('/entrepreneur-level');
    };
    
    return {
      motivations,
      selectedMotivations,
      toggleMotivation,
      goNext,
      goBack
    };
  }
});
</script>

<style scoped>
.motivation-selection {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.header {
  padding: 20px;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.progress-indicator {
  width: 100%;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background-color: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.progress {
  height: 100%;
  background-color: var(--primary-color);
  transition: width 0.3s ease;
}

.container {
  flex: 1;
  padding: 20px;
  display: flex;
  flex-direction: column;
}

.title {
  margin-bottom: 5px;
  text-align: center;
}

.subtitle {
  margin-bottom: 30px;
  text-align: center;
  color: var(--text-color-secondary);
}

.motivation-options {
  display: flex;
  flex-direction: column;
  gap: 15px;
  margin-bottom: 40px;
}

.motivation-option {
  display: flex;
  align-items: center;
  padding: 15px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: all 0.2s ease;
}

.motivation-option:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.motivation-option.selected {
  border: 2px solid var(--primary-color);
  background-color: rgba(52, 152, 219, 0.1);
}

.checkbox {
  width: 24px;
  height: 24px;
  border-radius: 4px;
  border: 2px solid var(--text-color-secondary);
  margin-right: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.motivation-option.selected .checkbox {
  border-color: var(--primary-color);
  background-color: var(--primary-color);
}

.checkbox-inner {
  width: 14px;
  height: 14px;
  position: relative;
}

.checkbox-inner:before, .checkbox-inner:after {
  content: '';
  position: absolute;
  background-color: white;
}

.checkbox-inner:before {
  width: 2px;
  height: 8px;
  transform: rotate(-45deg);
  top: 2px;
  left: 2px;
}

.checkbox-inner:after {
  width: 2px;
  height: 14px;
  transform: rotate(45deg);
  top: -1px;
  left: 8px;
}

.motivation-text {
  font-weight: 500;
}

.navigation {
  display: flex;
  justify-content: space-between;
  margin-top: auto;
}

@media (max-width: 767px) {
  .motivation-option {
    padding: 12px;
  }
  
  .checkbox {
    width: 20px;
    height: 20px;
  }
  
  .checkbox-inner {
    width: 12px;
    height: 12px;
  }
}
</style>
