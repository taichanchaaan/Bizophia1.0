<template>
  <div class="course-overview">
    <div class="header">
      <div class="progress-indicator">
        <div class="progress-bar">
          <div class="progress" :style="{ width: '80%' }"></div>
        </div>
      </div>
    </div>
    
    <div class="container">
      <div class="illustration">
        <svg width="250" height="150" viewBox="0 0 250 150" xmlns="http://www.w3.org/2000/svg">
          <rect x="20" y="20" width="210" height="110" rx="10" fill="#f5f5f5" stroke="#3498db" stroke-width="2"/>
          <circle cx="125" cy="50" r="20" fill="#3498db"/>
          <rect x="60" y="80" width="130" height="10" rx="5" fill="#3498db"/>
          <rect x="60" y="100" width="130" height="10" rx="5" fill="#3498db"/>
          <path d="M60,50 L90,50 M160,50 L190,50" stroke="#3498db" stroke-width="2"/>
        </svg>
      </div>
      
      <h2 class="title">シード期：アイデア検証</h2>
      
      <p class="description">
        このコースでは、ビジネスアイデアの創出と初期コンセプトの検証方法を学びます。
      </p>
      
      <ul class="features">
        <li>MVPの設計</li>
        <li>初期市場調査</li>
        <li>仮説検証</li>
      </ul>
      
      <button class="btn-primary start-button" @click="startSimulation">スタート</button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue';
import { useRouter } from 'vue-router';

export default defineComponent({
  name: 'CourseOverview',
  setup() {
    const router = useRouter();
    
    const startSimulation = () => {
      router.push('/simulation-session');
    };
    
    return {
      startSimulation
    };
  }
});
</script>

<style scoped>
.course-overview {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.header {
  padding: 20px;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.progress-indicator {
  width: 100%;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background-color: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.progress {
  height: 100%;
  background-color: var(--primary-color);
  transition: width 0.3s ease;
}

.container {
  flex: 1;
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.illustration {
  margin-bottom: 20px;
}

.title {
  margin-bottom: 20px;
}

.description {
  margin-bottom: 20px;
  max-width: 600px;
}

.features {
  list-style-type: none;
  margin-bottom: 40px;
  padding: 0;
  text-align: left;
  width: 100%;
  max-width: 300px;
}

.features li {
  position: relative;
  padding-left: 30px;
  margin-bottom: 10px;
}

.features li:before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 20px;
  height: 20px;
  background-color: var(--primary-color);
  border-radius: 50%;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z' fill='white'/%3E%3C/svg%3E");
  background-size: 12px;
  background-position: center;
  background-repeat: no-repeat;
}

.start-button {
  width: 200px;
  font-size: 1.2rem;
}

@media (max-width: 767px) {
  .illustration svg {
    width: 200px;
    height: 120px;
  }
}
</style>
