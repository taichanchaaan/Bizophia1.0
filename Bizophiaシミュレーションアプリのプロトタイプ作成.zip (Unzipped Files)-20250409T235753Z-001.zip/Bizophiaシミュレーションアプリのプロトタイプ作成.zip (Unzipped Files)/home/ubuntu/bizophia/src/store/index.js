const state = {
  user: {
    id: null,
    name: '',
    selectedIndustry: '',
    entrepreneurLevel: '',
    motivations: [],
    progress: {
      currentSession: 'seed',
      completedSessions: [],
      streak: 1
    },
    sessionResults: {
      seedStage: {
        completed: false,
        score: 0,
        answers: []
      }
    }
  },
  currentQuestion: 0,
  questions: [
    {
      id: "seed_q1",
      type: "free_text",
      prompt: "選択した業界で、あなたが解決したい問題は何ですか？",
      answer: "",
      feedback: ""
    },
    {
      id: "seed_q2",
      type: "multiple_choice",
      prompt: "あなたのビジネスアイデアの主なターゲット顧客は誰ですか？",
      options: [
        "できるだけ広い市場の全ての人",
        "特定の業界の企業（B2B）",
        "特定の属性や問題を持つ消費者（B2C）",
        "政府や公共機関（B2G）"
      ],
      answer: null,
      feedback: ""
    },
    {
      id: "seed_q3",
      type: "scenario_choice",
      prompt: "以下のシナリオで、最も効果的な価値提案はどれですか？",
      scenario: "あなたは教育分野のAIアプリを開発しています。潜在的な顧客に価値を伝える必要があります。",
      options: [
        "私たちのAIアプリは最先端の技術を使用しており、複雑なアルゴリズムで学習体験を向上させます。",
        "私たちのAIアプリを使えば、学習時間を40%削減しながら、テスト結果を平均20%向上させることができます。",
        "私たちのAIアプリは、他の教育アプリよりも多くの機能を提供し、より安価です。",
        "私たちのAIアプリは、有名な教育専門家によって開発され、多くの学校で採用されています。"
      ],
      answer: null,
      feedback: ""
    },
    {
      id: "seed_q4",
      type: "fill_in_blank",
      prompt: "あなたのビジネスの主な収益源について考えてみましょう。",
      template: "私たちのビジネスは主に [BLANK] から収益を得る予定です。この収益モデルを選んだ理由は [BLANK] です。",
      answer: {
        blank1: "",
        blank2: ""
      },
      feedback: ""
    },
    {
      id: "seed_q5",
      type: "binary_choice",
      prompt: "限られたリソースで最初に開発すべき機能はどちらですか？",
      options: [
        "多くの機能を持つ完成度の高い製品を時間をかけて開発する",
        "核となる価値を提供する最小限の機能を持つ製品を素早く市場に投入する"
      ],
      answer: null,
      feedback: ""
    }
  ]
};

const mutations = {
  SET_INDUSTRY(state, industry) {
    state.user.selectedIndustry = industry;
  },
  SET_ENTREPRENEUR_LEVEL(state, level) {
    state.user.entrepreneurLevel = level;
  },
  SET_MOTIVATIONS(state, motivations) {
    state.user.motivations = motivations;
  },
  SET_CURRENT_QUESTION(state, questionIndex) {
    state.currentQuestion = questionIndex;
  },
  SET_ANSWER(state, { questionIndex, answer }) {
    state.questions[questionIndex].answer = answer;
  },
  SET_FEEDBACK(state, { questionIndex, feedback }) {
    state.questions[questionIndex].feedback = feedback;
  },
  COMPLETE_SESSION(state, score) {
    state.user.sessionResults.seedStage.completed = true;
    state.user.sessionResults.seedStage.score = score;
    state.user.sessionResults.seedStage.answers = state.questions.map(q => q.answer);
    state.user.progress.completedSessions.push('seed');
  }
};

const actions = {
  setIndustry({ commit }, industry) {
    commit('SET_INDUSTRY', industry);
  },
  setEntrepreneurLevel({ commit }, level) {
    commit('SET_ENTREPRENEUR_LEVEL', level);
  },
  setMotivations({ commit }, motivations) {
    commit('SET_MOTIVATIONS', motivations);
  },
  nextQuestion({ commit, state }) {
    if (state.currentQuestion < state.questions.length - 1) {
      commit('SET_CURRENT_QUESTION', state.currentQuestion + 1);
    }
  },
  previousQuestion({ commit, state }) {
    if (state.currentQuestion > 0) {
      commit('SET_CURRENT_QUESTION', state.currentQuestion - 1);
    }
  },
  submitAnswer({ commit, state }, answer) {
    commit('SET_ANSWER', { 
      questionIndex: state.currentQuestion, 
      answer 
    });
    
    // フィードバック生成ロジック
    let feedback = "";
    const currentQuestion = state.questions[state.currentQuestion];
    
    switch (currentQuestion.id) {
      case "seed_q1":
        // 自由記述系の評価
        if (answer.length > 20) {
          feedback = "素晴らしいアイデアです！問題を明確に特定することは、ビジネスの成功の第一歩です。次のステップでは、この問題に対する解決策をさらに具体化していきましょう。";
        } else {
          feedback = "もう少し詳細に問題を説明すると良いでしょう。顧客のニーズや市場の課題に焦点を当てると、より価値のある解決策を提案できます。";
        }
        break;
        
      case "seed_q2":
        // 4択系の評価
        const feedbacks = [
          "広すぎるターゲット設定は、リソースの分散や明確な価値提案の欠如につながる可能性があります。より具体的なターゲットから始めることを検討してみましょう。",
          "B2Bモデルは有効な戦略ですが、具体的にどのような企業が最も価値を感じるかを特定することが重要です。",
          "素晴らしい選択です！特定の属性や問題を持つ消費者をターゲットにすることで、明確な価値提案が可能になり、初期の市場浸透が容易になります。",
          "政府や公共機関向けのビジネスは安定性がありますが、販売サイクルが長く、規制も多い傾向があります。スタートアップ初期には参入障壁が高い場合があります。"
        ];
        feedback = feedbacks[answer];
        break;
        
      case "seed_q3":
        // シナリオ選択系の評価
        const scenarioFeedbacks = [
          "技術的な詳細は開発者にとっては重要ですが、顧客は技術そのものではなく、その技術が彼らにもたらす具体的なメリットに関心があります。",
          "素晴らしい選択です！具体的な数値を用いた価値提案は、顧客にとって明確で説得力があります。学習時間の削減とテスト結果の向上という具体的なメリットを示すことで、顧客は自分にとっての価値を理解しやすくなります。",
          "競合との比較は有効ですが、「多くの機能」や「より安価」といった曖昧な表現では説得力に欠けます。具体的にどの機能がどのような価値をもたらすのかを示すことが重要です。",
          "権威や採用実績は信頼性を高める要素ですが、それだけでは顧客自身が得られる具体的なメリットが伝わりません。実績と具体的な価値提案を組み合わせるとより効果的です。"
        ];
        feedback = scenarioFeedbacks[answer];
        break;
        
      case "seed_q4":
        // 穴埋め系の評価
        if (answer.blank1.length > 5 && answer.blank2.length > 10) {
          feedback = "収益モデルの選択と理由付けが明確です。選択した収益モデルがターゲット顧客と提供する価値に適合しているか、また長期的にスケーラブルかを常に検討することが重要です。";
        } else {
          feedback = "収益モデルはビジネスの持続可能性の核心です。もう少し詳細に収益モデルとその選択理由を説明すると良いでしょう。";
        }
        break;
        
      case "seed_q5":
        // 二択強制選択系の評価
        if (answer === 1) {
          feedback = "素晴らしい選択です！MVPアプローチは、最小限の機能で核となる価値を提供し、早期に市場からフィードバックを得ることができます。これにより、リソースを効率的に使いながら、顧客のニーズに合わせて製品を進化させることができます。";
        } else {
          feedback = "完成度の高い製品を目指すことは理解できますが、開発に時間がかかりすぎると市場の変化に対応できなくなったり、顧客のニーズとずれたりするリスクがあります。初期段階では、核となる価値を素早く検証することが重要です。";
        }
        break;
    }
    
    commit('SET_FEEDBACK', { 
      questionIndex: state.currentQuestion, 
      feedback 
    });
    
    return feedback;
  },
  completeSession({ commit, state }) {
    // 簡易的なスコア計算
    let score = 0;
    const questions = state.questions;
    
    // 各問題のスコア計算
    questions.forEach((question, index) => {
      if (question.answer) {
        switch (question.id) {
          case "seed_q1":
            // 自由記述系
            score += question.answer.length > 20 ? 20 : 10;
            break;
          case "seed_q2":
            // 4択系（正解は2）
            score += question.answer === 2 ? 20 : 10;
            break;
          case "seed_q3":
            // シナリオ選択系（正解は1）
            score += question.answer === 1 ? 20 : 10;
            break;
          case "seed_q4":
            // 穴埋め系
            const blank1Length = question.answer.blank1 ? question.answer.blank1.length : 0;
            const blank2Length = question.answer.blank2 ? question.answer.blank2.length : 0;
            score += (blank1Length > 5 && blank2Length > 10) ? 20 : 10;
            break;
          case "seed_q5":
            // 二択強制選択系（正解は1）
            score += question.answer === 1 ? 20 : 10;
            break;
        }
      }
    });
    
    commit('COMPLETE_SESSION', score);
    return score;
  }
};

const getters = {
  currentQuestion: state => state.questions[state.currentQuestion],
  progress: state => (state.currentQuestion / state.questions.length) * 100,
  isLastQuestion: state => state.currentQuestion === state.questions.length - 1,
  isFirstQuestion: state => state.currentQuestion === 0,
  sessionCompleted: state => state.user.sessionResults.seedStage.completed,
  sessionScore: state => state.user.sessionResults.seedStage.score,
  userProfile: state => state.user
};

export default {
  state,
  mutations,
  actions,
  getters
};
