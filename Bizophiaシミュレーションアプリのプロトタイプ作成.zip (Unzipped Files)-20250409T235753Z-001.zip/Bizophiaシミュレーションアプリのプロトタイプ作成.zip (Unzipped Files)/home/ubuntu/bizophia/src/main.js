import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import { createStore } from 'vuex';
import App from './App.vue';
import routes from './router';
import storeConfig from './store';

// CSSリセットとグローバルスタイル
import './assets/styles.css';

// ルーターの設定
const router = createRouter({
  history: createWebHistory(),
  routes
});

// ストアの設定
const store = createStore(storeConfig);

// アプリケーションの作成とマウント
const app = createApp(App);
app.use(router);
app.use(store);
app.mount('#app');
