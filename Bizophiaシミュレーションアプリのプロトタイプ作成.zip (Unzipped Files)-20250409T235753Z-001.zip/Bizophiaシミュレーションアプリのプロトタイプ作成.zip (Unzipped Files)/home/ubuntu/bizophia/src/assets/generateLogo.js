// シンプルなロゴを作成するためのSVG
const svgLogo = `
<svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#3498db;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#9b59b6;stop-opacity:1" />
    </linearGradient>
  </defs>
  <circle cx="100" cy="100" r="80" fill="url(#grad1)" />
  <text x="100" y="115" font-family="Arial" font-size="32" font-weight="bold" text-anchor="middle" fill="white">Bizophia</text>
  <path d="M60,80 Q100,40 140,80" stroke="white" stroke-width="4" fill="none" />
  <path d="M60,120 Q100,160 140,120" stroke="white" stroke-width="4" fill="none" />
</svg>
`;

// SVGをBase64エンコード
const base64Logo = btoa(svgLogo);

// Base64エンコードされたSVGをデータURLとして出力
console.log('data:image/svg+xml;base64,' + base64Logo);
