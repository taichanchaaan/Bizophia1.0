<template>
  <div class="industry-selection">
    <div class="header">
      <div class="progress-indicator">
        <div class="progress-bar">
          <div class="progress" :style="{ width: '20%' }"></div>
        </div>
      </div>
    </div>
    
    <div class="container">
      <h2 class="title">あなたが興味のある業界を選んでください</h2>
      
      <div class="industry-grid">
        <div 
          v-for="(industry, index) in industries" 
          :key="index"
          class="industry-card"
          :class="{ 'selected': selectedIndustry === industry.value }"
          @click="selectIndustry(industry.value)"
        >
          <div class="industry-icon" v-html="industry.icon"></div>
          <div class="industry-name">{{ industry.name }}</div>
        </div>
      </div>
      
      <div class="navigation">
        <button class="btn-secondary" @click="goBack">戻る</button>
        <button 
          class="btn-primary" 
          :disabled="!selectedIndustry" 
          @click="goNext"
        >次へ</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'IndustrySelection',
  setup() {
    const router = useRouter();
    const store = useStore();
    const selectedIndustry = ref('');
    
    const industries = [
      {
        name: 'AI',
        value: 'ai',
        icon: '<svg viewBox="0 0 24 24" width="48" height="48"><path fill="#3498db" d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M12,6A6,6 0 0,1 18,12A6,6 0 0,1 12,18A6,6 0 0,1 6,12A6,6 0 0,1 12,6M12,8A4,4 0 0,0 8,12A4,4 0 0,0 12,16A4,4 0 0,0 16,12A4,4 0 0,0 12,8Z"></path></svg>'
      },
      {
        name: 'メタバース',
        value: 'metaverse',
        icon: '<svg viewBox="0 0 24 24" width="48" height="48"><path fill="#9b59b6" d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4C7.59,4 4,7.59 4,12C4,16.41 7.59,20 12,20C16.41,20 20,16.41 20,12C20,7.59 16.41,4 12,4M7,10L12,15L17,10H7Z"></path></svg>'
      },
      {
        name: 'ブロックチェーン',
        value: 'blockchain',
        icon: '<svg viewBox="0 0 24 24" width="48" height="48"><path fill="#f39c12" d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M7,7H17V9H7V7M7,11H17V13H7V11M7,15H17V17H7V15Z"></path></svg>'
      },
      {
        name: 'その他',
        value: 'other',
        icon: '<svg viewBox="0 0 24 24" width="48" height="48"><path fill="#2ecc71" d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M11,7H13V13H11V7M11,15H13V17H11V15Z"></path></svg>'
      }
    ];
    
    const selectIndustry = (industry) => {
      selectedIndustry.value = industry;
    };
    
    const goNext = () => {
      if (selectedIndustry.value) {
        store.dispatch('setIndustry', selectedIndustry.value);
        router.push('/entrepreneur-level');
      }
    };
    
    const goBack = () => {
      router.push('/');
    };
    
    return {
      industries,
      selectedIndustry,
      selectIndustry,
      goNext,
      goBack
    };
  }
});
</script>

<style scoped>
.industry-selection {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.header {
  padding: 20px;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.progress-indicator {
  width: 100%;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background-color: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.progress {
  height: 100%;
  background-color: var(--primary-color);
  transition: width 0.3s ease;
}

.container {
  flex: 1;
  padding: 20px;
  display: flex;
  flex-direction: column;
}

.title {
  margin-bottom: 30px;
  text-align: center;
}

.industry-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
  margin-bottom: 40px;
}

.industry-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: all 0.2s ease;
}

.industry-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.industry-card.selected {
  border: 2px solid var(--primary-color);
  background-color: rgba(52, 152, 219, 0.1);
}

.industry-icon {
  margin-bottom: 10px;
}

.industry-name {
  font-weight: 500;
  text-align: center;
}

.navigation {
  display: flex;
  justify-content: space-between;
  margin-top: auto;
}

@media (min-width: 768px) {
  .industry-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 767px) {
  .industry-grid {
    grid-template-columns: 1fr;
  }
}
</style>
