<template>
  <div class="home">
    <div class="logo-container">
      <img :src="logo" alt="Bizophia Logo" class="logo" />
    </div>
    <h1 class="title">Bizophia</h1>
    <p class="subtitle">起業シミュレーションで<br>ビジネススキルを学ぼう</p>
    <button class="btn-primary start-button" @click="startSimulation">はじめる</button>
    <p class="login-link" @click="goToLogin">ログイン</p>
  </div>
</template>

<script>
import { defineComponent } from 'vue';
import { useRouter } from 'vue-router';
import logoData from '../assets/logo.js';

export default defineComponent({
  name: 'Home',
  setup() {
    const router = useRouter();
    const logo = logoData;

    const startSimulation = () => {
      router.push('/industry-selection');
    };

    const goToLogin = () => {
      // 将来的にログイン機能を実装する場合に使用
      console.log('Login functionality will be implemented in future versions');
    };

    return {
      logo,
      startSimulation,
      goToLogin
    };
  }
});
</script>

<style scoped>
.home {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 20px;
  text-align: center;
}

.logo-container {
  margin-bottom: 20px;
}

.logo {
  width: 200px;
  height: auto;
}

.title {
  font-size: 2.5rem;
  margin-bottom: 10px;
  color: var(--primary-color);
}

.subtitle {
  font-size: 1.2rem;
  margin-bottom: 40px;
  line-height: 1.5;
}

.start-button {
  width: 200px;
  margin-bottom: 20px;
  font-size: 1.2rem;
}

.login-link {
  color: var(--primary-color);
  text-decoration: underline;
  cursor: pointer;
  font-size: 0.9rem;
}

@media (max-width: 767px) {
  .title {
    font-size: 2rem;
  }
  
  .subtitle {
    font-size: 1rem;
  }
}
</style>
