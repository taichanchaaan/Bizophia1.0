<template>
  <div class="session-complete">
    <div class="container">
      <div class="celebration-illustration">
        <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
          <circle cx="100" cy="100" r="80" fill="#2ecc71" />
          <path d="M85,130 L130,85 M85,85 L130,130" stroke="white" stroke-width="10" stroke-linecap="round" />
          <circle cx="40" cy="40" r="10" fill="#f39c12">
            <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite" />
          </circle>
          <circle cx="160" cy="40" r="10" fill="#f39c12">
            <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite" begin="0.3s" />
          </circle>
          <circle cx="40" cy="160" r="10" fill="#f39c12">
            <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite" begin="0.6s" />
          </circle>
          <circle cx="160" cy="160" r="10" fill="#f39c12">
            <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite" begin="0.9s" />
          </circle>
        </svg>
      </div>
      
      <h2 class="title">おめでとうございます！</h2>
      <p class="subtitle">シード期のセッションを完了しました</p>
      
      <div class="score-display">
        <div class="score-circle">
          <div class="score-value">{{ sessionScore }}</div>
          <div class="score-label">点</div>
        </div>
      </div>
      
      <div class="skills-acquired">
        <h3>獲得したスキル:</h3>
        <ul>
          <li>ビジネスアイデア創出</li>
          <li>ターゲット市場特定</li>
          <li>価値提案検証</li>
          <li>収益モデル検討</li>
          <li>MVP設計の基礎</li>
        </ul>
      </div>
      
      <div class="streak-display">
        <div class="streak-icon">🔥</div>
        <div class="streak-text">連続学習: {{ streak }}日目</div>
      </div>
      
      <button class="btn-primary home-button" @click="goToHome">ホームに戻る</button>
    </div>
  </div>
</template>

<script>
import { defineComponent, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'SessionComplete',
  setup() {
    const router = useRouter();
    const store = useStore();
    
    const sessionScore = computed(() => store.getters.sessionScore);
    const streak = computed(() => store.state.user.progress.streak);
    
    const goToHome = () => {
      router.push('/');
    };
    
    return {
      sessionScore,
      streak,
      goToHome
    };
  }
});
</script>

<style scoped>
.session-complete {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  padding: 20px;
}

.container {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  max-width: 600px;
  margin: 0 auto;
}

.celebration-illustration {
  margin-bottom: 20px;
  animation: bounce 1s ease infinite alternate;
}

@keyframes bounce {
  from { transform: translateY(0); }
  to { transform: translateY(-10px); }
}

.title {
  font-size: 2rem;
  margin-bottom: 10px;
  color: var(--success-color);
}

.subtitle {
  font-size: 1.2rem;
  margin-bottom: 30px;
}

.score-display {
  margin-bottom: 30px;
}

.score-circle {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background-color: var(--primary-color);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.score-value {
  font-size: 2.5rem;
  font-weight: 700;
}

.score-label {
  font-size: 1rem;
}

.skills-acquired {
  margin-bottom: 30px;
  background-color: #f5f5f5;
  padding: 20px;
  border-radius: 8px;
  width: 100%;
}

.skills-acquired h3 {
  margin-bottom: 10px;
  color: var(--primary-color);
}

.skills-acquired ul {
  list-style-type: none;
  padding: 0;
  text-align: left;
}

.skills-acquired li {
  position: relative;
  padding-left: 30px;
  margin-bottom: 10px;
}

.skills-acquired li:before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 20px;
  height: 20px;
  background-color: var(--primary-color);
  border-radius: 50%;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z' fill='white'/%3E%3C/svg%3E");
  background-size: 12px;
  background-position: center;
  background-repeat: no-repeat;
}

.streak-display {
  display: flex;
  align-items: center;
  margin-bottom: 30px;
}

.streak-icon {
  font-size: 1.5rem;
  margin-right: 10px;
}

.streak-text {
  font-size: 1.2rem;
  font-weight: 500;
}

.home-button {
  width: 200px;
  font-size: 1.2rem;
}

@media (max-width: 767px) {
  .title {
    font-size: 1.8rem;
  }
  
  .subtitle {
    font-size: 1rem;
  }
  
  .score-circle {
    width: 100px;
    height: 100px;
  }
  
  .score-value {
    font-size: 2rem;
  }
}
</style>
